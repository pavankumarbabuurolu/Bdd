package com.capg.log4j.Log4j;

import org.apache.log4j.Logger;

/**
 * Hello world!
 *
 */
public class App 
{
	
	 static Logger logger = Logger.getLogger(App.class.getName());
	
    public static void main( String[] args )
    {
        logger.info("pavan kumar");
    }
}
