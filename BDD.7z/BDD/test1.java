package com.capg.BDD.BDD;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"pretty"},
		tags= {"@cal"},
		//features= {"classpath:createDiffAccount/createDiffAccount.feature"})
		features= {"D:\\Pavan_Bdd\\BDD\\cal.featur"})
public class test1 {



}
