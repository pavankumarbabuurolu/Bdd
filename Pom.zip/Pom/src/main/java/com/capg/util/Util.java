package com.capg.util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Util {
	
	WebDriver driver;
	
	public void setDriver() {
		
	
	System.setProperty("webdriver.chrome.driver","D:\\selenium\\cfg\\chromedriver.exe");
	
	driver=new ChromeDriver();
	driver.manage().window().maximize();
	
	}
	public WebDriver getDriver() {
		
		driver.get("http://localhost:8081/Pom1/LoginFile.html?username=&password=");
		return driver;
		
	}

}
