package com.capg.stepdef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.capg.beans.Loginbean;
import com.capg.util.Util;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test {
	static WebDriver driver;
	Util u=new Util();
	private Loginbean pageBean ;
	@Before
	public void beforeScenario() {
/*System.setProperty("webdriver.chrome.driver","D:\\selenium\\cfg\\chromedriver.exe");
		
		driver=new ChromeDriver();
		driver.manage().window().maximize();*/
		
		u.setDriver();
		
	}
	
	@Given("^I have a loginpage$")
	public void i_have_a_loginpage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		/*driver.get("http://localhost:8081/Pom1/LoginFile.html?username=&password=");*/
	   driver=u.getDriver();
		pageBean= new Loginbean();
		PageFactory.initElements(driver, pageBean);
	}

	@When("^existing username and password is entered$")
	public void existing_username_and_password_is_entered() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	         pageBean.setUsername("Pavan");
	         pageBean.setPassword("pavan123");

	}

	@Then("^the result user should be loged in$")
	public void the_result_user_should_be_loged_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	
	
	pageBean.clicklog();
	

}
}
