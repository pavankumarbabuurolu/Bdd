package com.capg.beans;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Loginbean {
	
	@FindBy(how=How.NAME,name="username")
     private WebElement  user; 
	@FindBy(how=How.NAME,name="password")
    private WebElement  pass; 
	@FindBy(how=How.ID,id="sb1")
    private WebElement  login;
	@FindBy(how=How.ID,id="sb2")
    private WebElement  cancel;
	public String getUsername() {
		return user.getAttribute("value");
	}
	
	
 public void setUsername(String user) {
		this.user.clear();
		this.user.sendKeys(user);
	}
 public String getPassword() {
		return pass.getAttribute("value");
	}
 
 public void setPassword(String pass) {
		this.pass.clear();
		this.pass.sendKeys(pass);
	}
 
 

	 
	 public void  clicklog() {
		 login.click();
		 System.out.println("pavan");
	 }
	

	  

	    
	  
	
	
}
