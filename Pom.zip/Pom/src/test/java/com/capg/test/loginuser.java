package com.capg.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import junit.framework.TestCase;
/*@RunWith(Cucumber.class)
@CucumberOptions(
	 format = {"pretty", "html:target/html"},
		        features = {"classpath:Features/login"}
)*/
@RunWith(Cucumber.class)
@CucumberOptions(
		format = {"pretty", "html:target/reports"},
		features= {"features"},
		glue= {"com.capg.stepdef"},
		tags= {"@execute"}
	)





public class loginuser {

}
