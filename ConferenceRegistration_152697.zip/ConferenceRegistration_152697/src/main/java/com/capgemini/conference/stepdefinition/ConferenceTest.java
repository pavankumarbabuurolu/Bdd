package com.capgemini.conference.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;


import com.capgemini.conference.beans.ConferenceRegistration;
import com.capgemini.conference.beans.PersonalDetailsbeans;
import com.capgemini.conference.driverutil.DriverUtil;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class ConferenceTest {
	
	static ConferenceRegistration pageBean ;
	static PersonalDetailsbeans pageBean1 ;
	static WebDriver driver;
	DriverUtil  driverutil=new DriverUtil();

	@Before
	public void beforeScenario() {

		
		 driverutil.setDriver();
		
	}
	
	
	
	
	@Given("^User is on Conference room booking page$")
	public void user_is_on_Conference_room_booking_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver= driverutil.getDriver();
		 pageBean= new ConferenceRegistration();
			PageFactory.initElements(driver, pageBean);
	}

/*	@Given("^some other precondition$")
	public void some_other_precondition() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}
*/
	@When("^User select 'Next' link without entering 'FirstName'$")
	public void user_select_Next_link_without_entering_FirstName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageBean.clickNextPageLink();
	}

	@Then("^'Please fill the First Name' message should display$")
	public void please_fill_the_First_Name_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the First Name";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User select 'Next' link without entering 'LastName'$")
	public void user_select_Next_link_without_entering_LastName() throws Throwable {
		driver.switchTo().alert().dismiss();
		
			pageBean.setFirstName("pavan");
			pageBean.clickNextPageLink();
		
	}

	@Then("^'Please fill the Last Name' message should display$")
	public void please_fill_the_Last_Name_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Last Name";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User select 'Next' link without entering 'Email'$")
	public void user_select_Next_link_without_entering_Email() throws Throwable {
	    
		driver.switchTo().alert().dismiss();
		
		pageBean.setLastName("kumar");
		pageBean.clickNextPageLink();
	}

	@Then("^'Please fill the Email' message should display$")
	public void please_fill_the_Email_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Email";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User select 'Next' link after entering invalid 'Email' address$")
	public void user_select_Next_link_after_entering_invalid_Email_address() throws Throwable {
	    
		driver.switchTo().alert().dismiss();
		
			pageBean.setEmail("pavan.kumar.cap.com");
			pageBean.clickNextPageLink();
	}

	@Then("^Please enter valid Email Id' message should display$")
	public void please_enter_valid_Email_Id_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please enter valid Email Id.";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User select 'Next' link without entering 'Contact No'$")
	public void user_select_Next_link_without_entering_Contact_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		
		pageBean.setEmail("babuurolu.kumar@capgemini.com");
		pageBean.clickNextPageLink();
	}

	@Then("^Please fill the Contact No' message should display$")
	public void please_fill_the_Contact_No_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Contact No.";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User select 'Next' link after entering invalid 'Contact No$")
	public void user_select_Next_link_after_entering_invalid_Contact_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		
		pageBean.setContactNo("123456789");
		pageBean.clickNextPageLink();
	}

	@Then("^Please enter valid Contact no' message should display$")
	public void please_enter_valid_Contact_no_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please enter valid Contact no.";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User select 'Next' link without selecting  'Number of people attending$")
	public void user_select_Next_link_without_selecting_Number_of_people_attending() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		
		pageBean.setContactNo("7702090511");
		pageBean.clickNextPageLink();
	}

	@Then("^Please fill the Number of people attending' message should display$")
	public void please_fill_the_Number_of_people_attending_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Number of people attending";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User select 'Next' link without entereing  'Building Name & Room No'$")
	public void user_select_Next_link_without_entereing_Building_Name_Room_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		
		pageBean.setNoOfPerson("4");
		pageBean.clickNextPageLink();
	}

	@Then("^'Please fill the Building & Room No' message should display$")
	public void please_fill_the_Building_Room_No_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Building & Room No";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User select 'Next' link without entereing  'Area Name'$")
	public void user_select_Next_link_without_entereing_Area_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		
		pageBean.setBuildingAndRoomNo("c building, flat 414 ,e Society");
		pageBean.clickNextPageLink();
	}

	@Then("^Please fill the Area name' message should display$")
	public void please_fill_the_Area_name_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Area name";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User select 'Next' link without selecting  'City'$")
	public void user_select_Next_link_without_selecting_City() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		
		pageBean.setAreaName("Medchal,krupa");
		pageBean.clickNextPageLink();
	}

	@Then("^Please select city' message should display$")
	public void please_select_city_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please select city";
		Assert.assertEquals(expectedMessage, actualMessage);
	}
	

	@When("^User select 'Next' link without selecting  'State'$")
	public void user_select_Next_link_without_selecting_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		
		pageBean.setCity("Hyderabad");
		pageBean.clickNextPageLink();
	}

	@Then("^Please select state' message should display$")
	public void please_select_state_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please select state";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User select 'Next' link without selecting  'MemberShip Status$")
	public void user_select_Next_link_without_selecting_MemberShip_Status() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		
		pageBean.setState("Telangana");
		pageBean.clickNextPageLink();
	
	}

	@Then("^'Please Select MemeberShip status' message should display$")
	public void please_Select_MemeberShip_status_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please Select MemeberShip status";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User select 'Next' link after entering Valid set of information$")
	public void user_select_Next_link_after_entering_Valid_set_of_information() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setFirstName("pavan");
		pageBean.setLastName("kumar");
		pageBean.setEmail("babuurolu.kumar@capgemini.com");
		pageBean.setContactNo("7702090511");
		pageBean.setNoOfPerson("4");
		pageBean.setBuildingAndRoomNo("c building, flat 414 ,e Society");
		pageBean.setAreaName("Medchal,Krupa");
		pageBean.setCity("Hyderabad");
		pageBean.setState("Telangana");
		pageBean.setMemberStatus("member");
		pageBean.clickNextPageLink();
	}

	@Then("^'Personal details are validated\\.' message should display$")
	public void personal_details_are_validated_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Personal details are validated.";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		 
	}
	
	@Given("^User is on PaymentDetails page$")
	public void user_is_on_PaymentDetails_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if(driver.getTitle().equals("Payment Details"))
		 pageBean1= new PersonalDetailsbeans();
			PageFactory.initElements(driver, pageBean1);
	}

	@When("^User clicking on 'Make Payment' without entering 'Card Holder Name'$")
	public void user_clicking_on_Make_Payment_without_entering_Card_Holder_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageBean1.clickNext();
	}

	@Then("^'Please fill the Card Holder Name ' message should display$")
	public void please_fill_the_Card_Holder_Name_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Card holder name";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User clicking on 'Make Payment' without entering 'Debit card Number'$")
	public void user_clicking_on_Make_Payment_without_entering_Debit_card_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		pageBean1.setCardHolder("pavan");
		pageBean1.clickNext();
	}

	@Then("^'Please fill the Debit card Number' message should display$")
	public void please_fill_the_Debit_card_Number_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Debit card Number";
		Assert.assertEquals(expectedMessage, actualMessage);
	}
	@When("^User clicking on 'Make Payment' without entering 'Cvv'$")
	public void user_clicking_on_Make_Payment_without_entering_Cvv() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		pageBean1.setCardHolder("pavan");
		pageBean1.setdeb("1232344");
		pageBean1.clickNext();
	}

	@Then("^'Please fill the CVV' message should display$")
	public void please_fill_the_CVV_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the CVV";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User clicking on 'Make Payment' without entering 'Card expiration month'$")
	public void user_clicking_on_Make_Payment_without_entering_Card_expiration_month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		pageBean1.setCardHolder("pavan");
		pageBean1.setdeb("1232344");
		pageBean1.setCvv("123");
		pageBean1.clickNext();
	}

	@Then("^'Please fill the  expiration month' message should display$")
	public void please_fill_the_expiration_month_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill expiration month";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User clicking on 'Make Payment' without entering 'Card expiration year'$")
	public void user_clicking_on_Make_Payment_without_entering_Card_expiration_year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		pageBean1.setCardHolder("pavan");
		pageBean1.setdeb("1232344");
		pageBean1.setCvv("123");
		pageBean1.setMon("12");
		pageBean1.clickNext();
	}

	@Then("^'Please fill the  expiration year' message should display$")
	public void please_fill_the_expiration_year_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the expiration year";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User clicking on 'Make Payment' with 'valid data'$")
	public void user_clicking_on_Make_Payment_with_valid_data() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		pageBean1.setCardHolder("pavan");
		pageBean1.setdeb("1232344");
		pageBean1.setCvv("123");
		pageBean1.setMon("12");
		pageBean1.setyear("2018");
		pageBean1.clickNext();
	}

	@Then("^'Conference Room Booking successfully Done!!!' message should display$")
	public void conference_Room_Booking_successfully_Done_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Conference Room Booking successfully done!!!";
		Assert.assertEquals(expectedMessage, actualMessage);
	}	
	


}
