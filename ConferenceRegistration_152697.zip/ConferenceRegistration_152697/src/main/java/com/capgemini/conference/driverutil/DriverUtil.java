package com.capgemini.conference.driverutil;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DriverUtil {
WebDriver driver;
	
	public void setDriver() {
		
	
	System.setProperty("webdriver.chrome.driver","D:\\selenium\\cfg\\chromedriver.exe");
	
	
	
	}
	public WebDriver getDriver() {
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("http://localhost:8081/ConferenceWeb/ConferenceRegistartion.html");
		return driver;
		
	}
   

}
