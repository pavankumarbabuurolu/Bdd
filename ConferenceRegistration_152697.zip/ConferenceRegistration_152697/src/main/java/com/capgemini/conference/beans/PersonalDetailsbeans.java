package com.capgemini.conference.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class PersonalDetailsbeans {
	
	
	@FindBy(how=How.ID,id="txtCardholderName")
	private WebElement holderName;
	
	@FindBy(how=How.ID,id="txtDebit")
	private WebElement debName;
	
	@FindBy(how=How.ID,id="txtCvv")
	private WebElement cvv;

	@FindBy(how=How.ID, id="txtMonth")
	private WebElement  month;
	

	@FindBy(how=How.ID, id="txtYear")
	private WebElement year;
	
	@FindBy(how=How.ID, id="btnPayment")
	private WebElement btn;
	public void clickNext() {
		btn.click();
	}
	
	public void setCardHolder(String card) {
		this.holderName.clear(); 
		this.holderName.sendKeys(card);
	}
	public String  setCardHolder() {
		return holderName.getAttribute("value");
	}
	
	
	public void setdeb(String deb) {
		this.debName.clear(); 
		this.debName.sendKeys(deb);
	}
	public String getdeb() {
		
		return debName.getAttribute("value");
	}
	
	
	
	public void setMon(String mon) {
		this. month.clear(); 
		this. month.sendKeys(mon);
	}
	
	
public String getmom() {
		
		return month.getAttribute("value");
	}
	
	
	public void setyear(String year) {
		this. year .clear(); 
		this.  year.sendKeys(year);
	}
public String getyear() {
		
		return year.getAttribute("value");
	}
	
	
	public void setCvv(String cvvn) {
		this.cvv.clear(); 
		this.cvv.sendKeys(cvvn);
	}
public String getcvv() {
		
		return cvv.getAttribute("value");
	}
	
	
}
