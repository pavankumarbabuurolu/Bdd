package com.capg.crrr.Config;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;



public class Registration   {
	
	
	WebDriver driver;
	
	
	 static Logger logger = Logger.getLogger(Registration.class.getName());
	
	@Test
	public void pavan(){
		System.setProperty("webdriver.chrome.driver","D:\\selenium\\cfg\\chromedriver.exe");
		
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://localhost:8081/Figcon/reg.html");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.name("txtFN")).sendKeys("Pavan");
		driver.findElement(By.name("txtLN")).sendKeys("kumar");
		driver.findElement(By.name("Email")).sendKeys("babuurolupavankumar@gmail.com");
		driver.findElement(By.name("Phone")).sendKeys("7702090511");
		Select s=new Select(driver.findElement(By.name("size")));
		   s.selectByIndex(2);
		   driver.findElement(By.name("Address")).sendKeys("1-189");
		   driver.findElement(By.name("Address2")).sendKeys("Medchal");
		   Select s1=new Select(driver.findElement(By.name("city")));
		   s1.selectByIndex(3);
		   Select s2=new Select(driver.findElement(By.name("state")));
		   s2.selectByIndex(2);
		   driver.findElement(By.name("memberStatus")).click();
		   
		   driver.findElement(By.linkText("Next")).click();
		   
		   Alert alert=driver.switchTo().alert();
		   alert.accept();
		   if(driver.getTitle().equals("Payment Details") ){
			   System.out.println("hhh");
				driver.findElement(By.id("txtCardholderName")).sendKeys("Pavan");
				driver.findElement(By.id("txtDebit")).sendKeys("kumar");
				driver.findElement(By.id("txtCvv")).sendKeys("babuurolup");
				driver.findElement(By.id("txtMonth")).sendKeys("55");
				driver.findElement(By.id("txtYear")).sendKeys("798");
				driver.findElement(By.id("btnPayment")).click();
			   
		   }
		   
		   Alert alert1=driver.switchTo().alert();
		   alert1.accept();
	
		
		logger.info("Done");
		
}
}
