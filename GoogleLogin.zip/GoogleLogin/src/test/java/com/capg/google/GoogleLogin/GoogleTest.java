package com.capg.google.GoogleLogin;


import org.apache.log4j.Logger;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GoogleTest {
	static Logger logger = Logger.getLogger(GoogleTest.class.getName());
	static WebDriver driver;
	 
	@org.junit.Before
	public void initialisation() {

		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\cfg\\chromedriver.exe");

		driver = new ChromeDriver();
		driver.manage().window().maximize();

	}

	@Test
	public void github() {
		try {
			i_have_GoogleAccount();
			username_and_password_matches_with_the_existing_username_and_password();
			redirect_to_the_Login_jsp();

		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Given("^I have GoogleAccount$")
	public static void i_have_GoogleAccount() throws Throwable {
		driver.get("https://github.com/login?return_to=%2Fjoin%3Fsource%3Dheader-home");
		
		 logger.info("given");
	}

	@When("^username and password matches with the existing username and password$")
	public static void username_and_password_matches_with_the_existing_username_and_password() throws Throwable {
		driver.findElement(By.name("login")).sendKeys("babuurolupavankumar@gmail.com");
		driver.findElement(By.name("password")).sendKeys("Pavan@461");
		 logger.info("pavan kumar");
	}

	@Then("^redirect to the Login\\.jsp$")
	public static void redirect_to_the_Login_jsp() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("commit")).click();
		;
	}
}