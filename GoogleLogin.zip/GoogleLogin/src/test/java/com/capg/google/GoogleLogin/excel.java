package com.capg.google.GoogleLogin;

import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class excel {
	static WebDriver driver;
	//static Logger logger = Logger.getLogger(excel.class.getName());

	@Test
	public void test() {
		
		//System.setProperty("webdriver.chrome.driver", "D:\\selenium\\cfg\\chromedriver.exe");

		//driver = new ChromeDriver();
	//	driver.manage().window().maximize();

		//driver.get("https://github.com/login?return_to=%2Fjoin%3Fsource%3Dheader-home");
		
		try {
			readXLSFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
		
		public static void readXLSFile() throws IOException{
			
			
			System.out.println("out");
			
			InputStream ExcelFileToRead = new FileInputStream("D:/selenium/testexcel.xlsx");
			
			XSSFWorkbook  wb = new XSSFWorkbook(ExcelFileToRead);
	XSSFWorkbook test = new XSSFWorkbook(); 
			
			XSSFSheet sheet = wb.getSheetAt(0);
			XSSFRow row; 
			XSSFCell cell;

			Iterator rows = sheet.rowIterator();

			while (rows.hasNext())
			{
				System.out.println("whwn");
				row=(XSSFRow) rows.next();
				Iterator cells = row.cellIterator();
				while (cells.hasNext())
				{
					cell=(XSSFCell) cells.next();
			
					if (cell.getCellType() == XSSFCell.CELL_TYPE_STRING)
					{
						System.out.print(cell.getStringCellValue()+" ");
					}
					else if(cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
					{
						System.out.print(cell.getNumericCellValue()+" ");
					}
					else
					{
						//U Can Handel Boolean, Formula, Errors
					}
				}
				System.out.println();
			}
		
	}

}
