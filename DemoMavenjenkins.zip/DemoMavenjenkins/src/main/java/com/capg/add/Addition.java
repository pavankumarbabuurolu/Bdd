package com.capg.add;

public class Addition {
	static int c;
	
	public static  void add(int a,int b) {
		 c=a+b;
		System.out.println("result    "  +c);
		
		
		
		
		
		  
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		add(1,2);

	}

}
